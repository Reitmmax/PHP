DELETE FROM customers
WHERE lastName = 'Smith' AND firstName = 'John'