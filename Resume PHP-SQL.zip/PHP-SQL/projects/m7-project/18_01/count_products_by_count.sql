SELECT COUNT(*) 
FROM products
WHERE categoryID = 1