UPDATE customers
SET customers.password = '5e5ame'
WHERE lastName = 'Smith' AND firstName = 'John'