INSERT INTO customers(customerID, emailAddress, password, firstName, lastName)
VALUES ( NULL, 'johnsmith@example.com', 'sesame', 'John', 'Smith') 